﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT2
{
    public partial class title : Form
    {
      private  int _x;
       private  int _y;
       
        public title()
        {
            InitializeComponent();
            _x = 350;
            _y = 250;
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2(this);
            this.Hide();
            f2.Show();
        }

        //form.BackGroundImage
        //  this.BackGroundImage=Image.FromFile
        //e.Graphics.FillRectangle(Brushes.BlueViolet,_x,_y,100,100)

        private void Form1_Load(object sender, EventArgs e)
        {

            //    }("D:\\tutorial/11-A/Oliynik Yaroslav/working/01.jpg")
        }

        private void title_HelpButtonClicked(object sender, CancelEventArgs e)
        {

        }

        private void title_PaddingChanged(object sender, EventArgs e)
        {

        }

        private void title_Paint(object sender, PaintEventArgs e)
        {
       
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3(this);
            this.Hide();
            f3.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5(this);
            this.Hide();
            f5.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

    
    }

   

}
