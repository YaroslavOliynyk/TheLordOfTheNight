﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT2
{
    public partial class Form2 : Form
    {
       public string s;
        
       
        public Form2()
        {
            InitializeComponent();
        }

        public string TextBoxText
        {
            get
            {
                return textBox1.Text;
            }

        }
        
        private title _f1;
        public Form2(title f1)
        {
            InitializeComponent();
            _f1 = f1;
        }

        private Form4 _f4;
        public Form2(Form4 f4)
        {
            InitializeComponent();
            _f4 = f4;
        }
      

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*Form f4 = new Form4();
           /* this.Hide();
            f4.Show();
            */s = textBox1.Text;
            if (textBox1.Text=="")
            {
                MessageBox.Show("Введіть ім'я майбутнього повелителя ночі!\n ", "Помилка");
            }
            else    
            {
                Form4 f4 = new Form4(this);
                this.Hide();
                f4.Passvalue = textBox1.Text;
                f4.ShowDialog();
                            
              /*00  Form4 f4 = new Form4(this);
                this.Hide();
                f4.Show();
                */
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            try
            {
                _f1.Show();
            }
            catch (NullReferenceException exception)
            {
                Application.Exit();
            }
        }
    }
}
