﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT2
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private title _f1;
        public Form5(title f1)
        {
            InitializeComponent();
            _f1 = f1;
        }
        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamReader fi = new StreamReader(Application.StartupPath + "/do_not_enter_pls/logpass.txt");
            int i = 0;
            bool flag = true;
            string[] st = new string[1000];
            while (!fi.EndOfStream)
            {
                st[i] = fi.ReadLine();
                i += 1;
            }
            fi.Close();
            for (int n = 0; n <= i; n+=2)
            {
                if (st[n] == textBox1.Text.ToString())
                {
                flag=false;
                }

            }
            if (flag==false)
            MessageBox.Show("Такий логін уже існує");
            if (flag==true)
            {
                string appendText=textBox1.Text.ToString()+Environment.NewLine;

            }








            }
        }
    }

  


