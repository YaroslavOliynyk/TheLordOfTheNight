﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJECT2
{
    public partial class Form4 : Form
    {
        private string Nm;
        public string Passvalue
    {
        get { return Nm; }
        set { Nm = value; }
    }
        
        Random rand = new Random();
         int k = 1;

        float[,] pole_1 = new float[1000000, 10];
        float[,] pole_2 = new float[1000000, 10];

    
        public int kil_ = 0;
        float x_1 = 0;
        float x_2 = 115;
        bool flag_left_1=false;
        bool flag_right_1 = false;
        bool flag_left_2 = false;
        bool flag_right_2 = false;
        bool flag_game_over = false;

       
 

       

        private Form2 _f2;
        public Form4(Form2 f2)
        {
            InitializeComponent();
            _f2 = f2;
        }              
 
        
        private void Form4_Load(object sender, EventArgs e)
        {
           label2.Text =Nm;
        }

        private void Form4_Paint(object sender, PaintEventArgs e)
        {
            
            //!!!!!!!!!
           // if ((flag_game_over==false) ||  (flag_game_over==true))
            {
                string pol = Convert.ToString(kil_);

               if (flag_right_1==true)
                {
                    x_1+=5;
                }
                if (flag_left_1==true)
                {
                    x_1-=5;
                }
                if (x_1 == 55)
                {
                    flag_left_1 = false;
                    flag_right_1 = false;
                }  
                if (x_1 == 0)
              
                {
                    flag_left_1 = false;
                    flag_right_1 = false;
                }

                if (flag_right_2)
                {
                    x_2 += 5;
                }
                if (flag_left_2)
                {
                    x_2 -= 5;
                }
                if (x_2 == 170)
                {
                    flag_left_2 = false;
                    flag_right_2 = false;
                }
                if (x_2 == 115)
                {
                    flag_left_2 = false;
                    flag_right_2 = false;
                }

                
                e.Graphics.FillRectangle(Brushes.Black, 50, 0, 5, 600);
              
                e.Graphics.FillRectangle(Brushes.Navy, 115, 0, 105, 600);
               e.Graphics.FillRectangle(Brushes.Navy, 0, 0, 105, 600);
                e.Graphics.FillRectangle(Brushes.Black, 105, 0, 5, 50);
               
                e.Graphics.FillRectangle(Brushes.PeachPuff, 165, 0, 5, 600);
                e.Graphics.FillRectangle(Brushes.PeachPuff, 50, 0, 5, 600);
                e.Graphics.FillRectangle(Brushes.LightSlateGray, 105, 0, 10, 600);
                                        
                System.Drawing.Font drawFont = new System.Drawing.Font("Arial", 40);
                System.Drawing.SolidBrush drawBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Red);
                System.Drawing.StringFormat drawFormat = new System.Drawing.StringFormat();
                if (kil_ < 10) { e.Graphics.DrawString(pol, drawFont, drawBrush, 87, 5, drawFormat);}
                else { e.Graphics.DrawString(pol, drawFont, drawBrush, 70, 5, drawFormat);}
                
                drawFont.Dispose();
                drawBrush.Dispose();
                // МАШИНИ

                e.Graphics.DrawImage(new Bitmap("red_car3.jpg"), x_1 + 10, 400, 30, 70);
               
                e.Graphics.DrawImage(new Bitmap("car3.jpg"), x_2 + 10, 400, 30, 70);
                
                // АБО КВАДРАТ АБО КРУГ НА 1 ЛІНІЇ
                int o = k - 6;
                if (o < 1) { o = 1; }
                for (int j = o; j <= k; j++)
                {

                    if (pole_1[j, 5] == 1)
                        e.Graphics.DrawImage(new Bitmap("moneta.jpg"), pole_1[j, 1], pole_1[j, 2], pole_1[j, 3], pole_1[j, 4]);
                    if (pole_1[j, 5] == 2)
                        e.Graphics.DrawImage(new Bitmap("box2.png"), pole_1[j, 1], pole_1[j, 2], pole_1[j, 3], pole_1[j, 3]);
                }
               // АБО КВАДРАТ АБО КРУГ НА 2 ЛІНІЇ
                o = k - 6;
                if (o < 1) o = 1;
                for (int j = o; j <= k; j++)
                {

                    if (pole_2[j, 5] == 1) e.Graphics.DrawImage(new Bitmap("moneta.jpg"), pole_2[j, 1], pole_2[j, 2], pole_2[j, 3], pole_2[j, 4]);
                    if (pole_2[j, 5] == 2) e.Graphics.DrawImage(new Bitmap("box2.png"), pole_2[j, 1], pole_2[j, 2], pole_2[j, 3], pole_2[j, 3]);
                }
 
               
            }
        }
       
        
        
        private void Form4_Paint1(object sender, PaintEventArgs e)
        {
            
        }
        
        
        
      void perevirka_1(int l)
        {
            if (l == 1)
            {
                int o = k - 6;
                if (o < 1) o = 1;
                for (int i = o; i <= k; i++)
                {
                    if (pole_1[i, 2] + 50 >= 400 && pole_1[i, 2] <= 400)
                    {
                        if (x_1 == pole_1[i, 1] && pole_1[i, 5] == 1)
                        {
                            pole_1[i, 5] = 0;
                            kil_++;
                        } 
                    }
                    if (pole_1[i, 2] + 50 > 500 && pole_1[i, 5] == 1)
                    {
                      string s = Convert.ToString(kil_);
                        flag_game_over = true;
                        if (kil_ < 77) { MessageBox.Show(Nm + "  ,на жаль, Ви не стали повелителем ночі\n " + "Ваш результат:" + s, "Програш"); }
                        else { MessageBox.Show(Nm + "  ,Ви змогли перевершити самого Богдіуса Фесіуса!\n " + "Ваш результат:" + s, "Перемога!"); }
             this.Dispose();

                        Form2 f2 = new Form2(this);
                        this.Hide();
                        f2.Show();
                    }
                }
                
            }
            if(l == 2)
            {
                int o = k - 6;
                if (o < 1) o = 1;
                for (int i = o; i <= k; i++)
                {
                    if (pole_1[i, 2] + 50 >= 400 && pole_1[i, 2] <= 400)
                    {
                        if (x_1 == pole_1[i, 1] && pole_1[i, 5] == 2)
                        {
                            string s = Convert.ToString(kil_);
                            flag_game_over = true;
                            if (kil_ < 77) { MessageBox.Show(Nm + "  ,на жаль, Ви не стали повелителем ночі\n " + "Ваш результат:" + s, "Програш"); }
                            else { MessageBox.Show(Nm + "  ,Ви змогли перевершити самого Богдіуса Фесіуса!\n " + "Ваш результат:" + s, "Перемога!"); }
                            this.Dispose();

                            Form2 f2 = new Form2(this);
                            this.Hide();
                            f2.Show();
                        }
                    }
                }
            }
        }

        void perevirka_2(int l)
        {
            if (l == 1)
            {
                int o = k - 6;
                if (o < 1) o = 1;
                for (int i = o; i <= k; i++)
                {
                    if (pole_2[i, 2] + 50 >= 400 && pole_2[i, 2] <= 400)
                    {
                        if (x_2 == pole_2[i, 1] && pole_2[i, 5] == 1)
                        {
                            pole_2[i, 5] = 0;
                            kil_++;
                        }
                       
                    }
                    if (pole_2[i, 2] + 50 > 500 && pole_2[i, 5] == 1)
                    {
                        string s = Convert.ToString(kil_);
                        flag_game_over = true;
                        if (kil_ < 77) { MessageBox.Show(Nm + "  ,на жаль, Ви не стали повелителем ночі\n " + "Ваш результат:" + s, "Програш"); }
                        else { MessageBox.Show(Nm + "  ,Ви змогли перевершити самого Богдіуса Фесіуса!\n " + "Ваш результат:" + s, "Перемога!"); }
                        this.Dispose();

                        Form2 f2 = new Form2(this);
                        this.Hide();
                        f2.Show();
                    }
                }
            }
            if (l == 2)
            {

                int o = k - 6;
                if (o < 1) o = 1;
                for (int i = o; i <= k; i++)
                {
                    if (pole_2[i, 2] + 50 >= 400 && pole_2[i, 2] <= 400)
                    {
                        if (x_2 == pole_2[i, 1] && pole_2[i, 5] == 2)
                        {
                            string s = Convert.ToString(kil_);
                            flag_game_over = true;
                            if (kil_ < 77) { MessageBox.Show(Nm + "  ,на жаль, Ви не стали повелителем ночі\n " + "Ваш результат:" + s, "Програш"); }
                            else { MessageBox.Show(Nm + "  ,Ви змогли перевершити самого Богдіуса Фесіуса!\n " + "Ваш результат:" + s, "Перемога!"); }
                            this.Dispose();

                            Form2 f2 = new Form2(this);
                            this.Hide();
                            f2.Show();
                        }
                    }
                }
            }
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            
            if (flag_game_over==false)
            {
                perevirka_1(1);
                perevirka_1(2);
                perevirka_2(1);
                perevirka_2(2);
                int o = k - 6;
                if (o < 1) o = 1;
                for (int i = o; i <= k; i++)
                {
                    pole_1[i,2] = pole_1[i,2] + 1*(kil_/10 + 2);
                }

                if (pole_1[k, 2] >= 200)
                {
                    int r = rand.Next(1, 3) ;
                    int r1 = rand.Next(1, 3) ;
                    k++;

                    if (r == 1) { pole_1[k, 5] = 1; } else { pole_1[k, 5] = 2; }
                    pole_1[k, 1] = 55 * (r1 - 1);
                    pole_1[k, 2] = 0;
                    pole_1
                        [k, 3] = 50;
                    pole_1[k, 4] = 50;
                }



                o = k - 7;
                if (o < 1) o = 1;
                for (int i = o; i <= k-1; i++)
                {
                    pole_2[i, 2] = pole_2[i, 2] + 1 * (kil_ / 10 + 2);
                }

                if (pole_2[k - 1, 2] >= 200)
                {
                    int r_2 = rand.Next(1, 1000) % 2 + 1;
                    int r1_2 = rand.Next(1, 1000) % 2 + 1;
                    
                    if (r_2 == 1) { pole_2[k, 5] = 1; } else { pole_2[k, 5] = 2; }


                    if (r1_2 == 1) pole_2[k, 1] = 170; else pole_2[k, 1] = 115;

                    pole_2[k, 2] = 0;

                    pole_2[k, 3] = 50;
                    pole_2[k, 4] = 50;

                }

                Invalidate();

            }
        }


          private void Form4_KeyPress(object sender, KeyPressEventArgs e)
          {
           
          }

          private void Form4_KeyDown(object sender, KeyEventArgs e)
          {
              if(e.KeyCode==Keys.A && flag_left_1==false && flag_right_1==false && x_1==55 && flag_game_over==false)
              {
                  flag_left_1 = true;
              }
              if (e.KeyCode == Keys.D && flag_left_1==false && flag_right_1==false && x_1 == 0 && flag_game_over==false)
              {
                  flag_right_1 = true;
              }
              if (e.KeyCode == Keys.Left && flag_left_2==false && flag_right_2==false && x_2 == 170 && flag_game_over==false)
              {
                  flag_left_2 = true;
              }
              if (e.KeyCode == Keys.Right && flag_left_2==false && flag_right_2==false && x_2 == 115 && flag_game_over==false)
              {
                  flag_right_2 = true;
              }
          }

          private void textBox1_TextChanged(object sender, EventArgs e)
          {
          }

          
    }
}
